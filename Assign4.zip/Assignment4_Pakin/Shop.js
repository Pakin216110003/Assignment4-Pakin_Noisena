var customername = "Pakin";
var price = 10;
var quantity = 3;
var totalPrice = 0;

document.getElementById("customername").innerHTML = "Pakin";
document.getElementById("price").innerHTML = "$" + totalPrice;
var products = [
	"Pizza",
	"Naan",
	"Sourdough",
	"Foccacia",
	"iphone X"
];
var price = [40,10,20,80,1000];
var productsText= "";
var productsElement = document.getElementById("product1");


hours = new Date().getHours();
if (hours<=11){
	document.getElementById("time").innerHTML="Good Morning";
}else if(hours<=16){
	document.getElementById("time").innerHTML="Good Afternoon";
}else{
	document.getElementById("time").innerHTML="Good Evening";
}

for (i in products){
	productsText= productsText + "<li class= 'list-group-item'>" + products[i] + "<span class= 'badge badge-pill badge-secondary float-right'> $ " + price[i] + "</li>";
	productsElement.innerHTML = productsText;
	totalPrice += price[i];
}

totalPrice = totalPrice * .75;
document.getElementById("price").innerHTML = "$" + totalPrice;
